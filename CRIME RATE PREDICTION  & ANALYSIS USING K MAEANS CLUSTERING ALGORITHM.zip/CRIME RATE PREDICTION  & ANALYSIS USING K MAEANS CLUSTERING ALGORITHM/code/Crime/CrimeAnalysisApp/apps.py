from django.apps import AppConfig


class CrimeanalysisappConfig(AppConfig):
    name = 'CrimeAnalysisApp'
